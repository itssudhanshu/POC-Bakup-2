<template class="ok">
  <v-container fluid>
    <v-layout row wrap>
      <v-flex xs4 class="ok1 text-xs-center" mt-3>
        <h1>Hoe page</h1>
      </v-flex>
      <v-flex xs4 class="text-xs-center" mt-3>
        <h1>Home page</h1>
      </v-flex>
      <v-flex xs4 class="text-xs-center" mt-3>
        <h1>Hom page</h1>
      </v-flex>
      <v-flex xs12 class="text-xs-center" mt-3>
        <p>This is a user's home page</p>
      </v-flex>
    </v-layout>
  </v-container>
</template>
<script>
export default {
  //name: 'Home'
};
</script>



