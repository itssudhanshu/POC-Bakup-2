<template>
  <v-container fluid>
    <v-layout row wrap>
      <v-flex xs12 class="text-xs-center" mt-5>
        <h1>404</h1>
        <p>Oops! Something is wrong.</p>
      </v-flex>
    </v-layout>
  </v-container>
</template>
<script>
export default {};
</script>
<style scoped>
@import ".././App.vue/error.css";
footer{
  display:none;
}
</style>

